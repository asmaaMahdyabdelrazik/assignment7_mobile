import 'package:assignment3/family_member.dart';
import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xff85e691),
        appBar: AppBar(
          backgroundColor: Color(0xff2f5519),
          title: Center(
            child: Text(
              'Language Learning App ',
            ),
          ),
        ),
        body: ListView(children: [
          Center(
            child: Text(
              "Your way to learn Japanese ",
              style: TextStyle(
                color: Color(0xff000000),
                fontSize: 25,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Card(
            color: Color(0xff277ec6),
            child: ListTile(
              onTap: (() {
                // Navigator.of(context).push(MaterialPageRoute(
                //   builder: (BuildContext context) => Novels()));
              }),
              title: Text('Numbers',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
              //subtitle: Text('Outher'),
            ),
          ),
          Card(
            color: Color(0xffeef444),
            child: ListTile(
              onTap: (() {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => family_mem()));
              }),
              title: Text(
                'Family Members',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
              ),
              // subtitle: Text('Outher'),
            ),
          ),
          Card(
            color: Color(0xfff458e7),
            child: ListTile(
              onTap: (() {
                // Navigator.of(context).push(MaterialPageRoute(
                // builder: (BuildContext context) => Notepad()));
              }),
              title: Text('Colors',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
              //subtitle: Text('Outher'),
            ),
          ),
        ]));
  }
}
